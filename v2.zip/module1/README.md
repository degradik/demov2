# Решение варианта 2 (В2_КОД 09.02.07-5-2026-БУ)

**Платформа:** РЕД ОС (Linux)  
**sudo:** не используется (всё в `$HOME` + venv)  
**СУБД:** PostgreSQL (локально в `~/pgdata-v2` или общий сервер)  
**Модуль 4:** `module4/`

---

## Зависимости

| Кто | Что |
|-----|-----|
| **Администратор** (один раз, с root) | `module4/packages-for-admin.txt` → `dnf install ...` |
| **Вы** (без sudo) | `./check-system-deps.sh`, `./setup-local-postgres.sh`, venv, pip |

### pip (`module4/requirements.txt`)

`psycopg2-binary`, `passlib[bcrypt]`, `bcrypt`, `Pillow`

### ОС (уже должны быть установлены админом)

`python3`, `python3-tkinter`, `postgresql` (команды `initdb`, `psql`, `pg_ctl`)

---

## Быстрый старт (без sudo)

```bash
# 1) SQL (Postgres уже запущен, БД V2 создана)
cd variant2/решение
psql -h localhost -p 5433 -d V2 -f БД.sql
psql -h localhost -p 5433 -d V2 -f insert.sql

# 2) Модуль 4
cd module4
pip install --user -r requirements.txt
python3 main.py
```

**Вход:** `admin` / `admin`

---

## Содержимое

| Файл | Модуль |
|------|--------|
| `БД.sql`, `insert.sql` | 2 |
| `query.sql` | 3 |
| `module4/` | 4 |
| `md5.md` | 5 |

`module4/config.py` — `localhost`, порт **5433**, БД **V2**.

---

## Сценарий 1. Первый запуск

### 1.1. Проверка системы (без sudo)

```bash
cd module4
./check-system-deps.sh
```

Если `[FAIL]` — администратору файл **`packages-for-admin.txt`**.

### 1.2. Свой PostgreSQL в домашней папке

```bash
./setup-local-postgres.sh
```

| Параметр | Значение |
|----------|----------|
| Данные | `~/pgdata-v2` |
| Порт | `5433` |
| БД | `V2` |
| Лог | `~/pgdata-v2.log` |

Остановка: `./stop-local-postgres.sh`

### 1.3. SQL

```bash
cd ../
psql -h localhost -p 5433 -d V2 -f БД.sql
psql -h localhost -p 5433 -d V2 -f insert.sql
psql -h localhost -p 5433 -d V2 -f query.sql
```

### 1.4. Python

```bash
cd module4
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
python check_deps.py
python main.py
```

---

## Сценарий 2. Обычный запуск

```bash
cd module4
./setup-local-postgres.sh    # если Postgres ещё не запущен
source .venv/bin/activate
python main.py
```

или `./run.sh`

---

## Сценарий 3. PostgreSQL уже на экзаменационном ПК

Не запускайте `setup-local-postgres.sh`. Узнайте host/port у администратора, пропишите в `config.py`, создайте БД `V2` через `psql`, выполните SQL-скрипты.

---

## Сценарий 4. Только модули 2–3

```bash
./module4/setup-local-postgres.sh   # при необходимости
psql -h localhost -p 5433 -d V2 -f БД.sql
psql -h localhost -p 5433 -d V2 -f insert.sql
psql -h localhost -p 5433 -d V2 -f query.sql
```

---

## Сценарий 5. Обновить pip-пакеты

```bash
cd module4
source .venv/bin/activate
pip install --upgrade -r requirements.txt
```

Пересоздать venv:

```bash
deactivate 2>/dev/null || true
rm -rf .venv
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

---

## Сценарий 6. Пересоздать БД

```bash
psql -h localhost -p 5433 -d postgres -c 'DROP DATABASE IF EXISTS "V2";'
psql -h localhost -p 5433 -d postgres -c 'CREATE DATABASE "V2";'
cd variant2/решение
psql -h localhost -p 5433 -d V2 -f БД.sql
psql -h localhost -p 5433 -d V2 -f insert.sql
```

---

## Модуль 4 — структура

```
module4/
├── main.py
├── requirements.txt
├── entities/user_manager.py
├── forms/forms.py
└── images/1.png … 4.png
```

Настройки БД: `entities/user_manager.py`

---

## Частые ошибки

| Симптом | Решение |
|---------|---------|
| `tkinter` FAIL | Админ: `dnf install python3-tkinter` |
| `initdb` не найден | Админ: `dnf install postgresql-server postgresql` |
| Connection refused | `./setup-local-postgres.sh` |
| Нет БД V2 | `./setup-local-postgres.sh` или `createdb -h localhost -p 5433 V2` |
| Заблокирован admin | SQL: `UPDATE users SET is_blocked=FALSE, failed_attempts=0 WHERE login='admin';` |

---

## Все команды (без sudo)

```bash
cd variant2/решение
psql -h localhost -p 5433 -d V2 -f БД.sql
psql -h localhost -p 5433 -d V2 -f insert.sql
cd module4
pip install --user -r requirements.txt
python3 main.py
```

Заказчик: **ООО "Хлебус"**.
