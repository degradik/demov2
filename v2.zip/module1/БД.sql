-- PostgreSQL: создание схемы (модуль 2)
-- Выполнение: psql -U postgres -d V2 -f БД.sql

CREATE TABLE customers (
    id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    inn VARCHAR(12),
    address VARCHAR(255),
    phone VARCHAR(20),
    is_seller BOOLEAN,
    is_buyer BOOLEAN
);

CREATE TABLE materials (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20),
    name VARCHAR(255) NOT NULL,
    unit VARCHAR(10) NOT NULL,
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0)
);

CREATE TABLE products (
    id SERIAL PRIMARY KEY,
    code VARCHAR(20),
    name VARCHAR(255) NOT NULL,
    unit VARCHAR(10) NOT NULL,
    price NUMERIC(10, 2) NOT NULL CHECK (price >= 0)
);

CREATE TABLE specifications (
    product_id INT REFERENCES products(id),
    material_id INT REFERENCES materials(id),
    quantity NUMERIC(10, 3) NOT NULL CHECK (quantity > 0),
    PRIMARY KEY (product_id, material_id)
);

CREATE TABLE orders (
    id SERIAL PRIMARY KEY,
    order_date DATE NOT NULL,
    customer_id VARCHAR(20) REFERENCES customers(id),
    total_amount NUMERIC(12, 2) NOT NULL CHECK (total_amount >= 0)
);

CREATE TABLE order_items (
    order_id INT REFERENCES orders(id),
    product_id INT REFERENCES products(id),
    quantity INT NOT NULL CHECK (quantity > 0),
    price NUMERIC(10, 2) NOT NULL,
    subtotal NUMERIC(10, 2) NOT NULL,
    PRIMARY KEY (order_id, product_id)
);
