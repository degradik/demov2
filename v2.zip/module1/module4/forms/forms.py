import os
import random
import tkinter as tk
from tkinter import messagebox, simpledialog, ttk

from PIL import Image, ImageTk

from entities.user_manager import (
    COMPANY,
    DEF_PWD,
    ERR_BLK,
    ERR_PWD,
    MSG_OK,
    UserManager,
)

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG_DIR = os.path.join(BASE, "images")


class Captcha(tk.Toplevel):
    def __init__(self, master, on_ok):
        super().__init__(master)
        self.title(f"{COMPANY} - Проверка безопасности")
        self.geometry("280x320")
        self.minsize(250, 300)
        self.transient(master)
        self.grab_set()
        self.on_ok = on_ok
        self.sel = None
        self.pos = [0, 1, 2, 3]
        random.shuffle(self.pos)
        self.btns, self.imgs = [], []
        for i in range(1, 5):
            path = os.path.join(IMG_DIR, f"{i}.png")
            if not os.path.exists(path):
                messagebox.showerror("Ошибка", f"Нет файла images/{i}.png")
                self.destroy()
                master.destroy()
                return
            img = Image.open(path).resize((100, 100), Image.LANCZOS)
            self.imgs.append(ImageTk.PhotoImage(img))
        f = tk.Frame(self)
        f.pack(pady=10)
        for i in range(2):
            for j in range(2):
                b = tk.Button(f, width=100, height=100, command=lambda x=i * 2 + j: self._swap(x))
                b.grid(row=i, column=j, padx=2, pady=2)
                self.btns.append(b)
        self._draw()
        tk.Button(self, text="Подтвердить", command=lambda: (self.on_ok(self.pos == [0, 1, 2, 3]), self.destroy())).pack(pady=5)
        tk.Label(self, text="Кликните два фрагмента для обмена").pack()

    def _draw(self):
        for i, b in enumerate(self.btns):
            b.config(image=self.imgs[self.pos[i]])

    def _swap(self, i):
        if self.sel is None:
            self.sel = i
        else:
            self.pos[self.sel], self.pos[i] = self.pos[i], self.pos[self.sel]
            self.sel = None
            self._draw()


class Login(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Авторизация - {COMPANY}")
        self.geometry("350x220")
        self.minsize(300, 180)
        f = tk.Frame(self)
        f.pack(fill="x", padx=20, pady=10)
        tk.Label(self, text="Вход в систему").pack()
        tk.Label(f, text="Логин:").grid(row=0, column=0, sticky="e", padx=5, pady=5)
        self.e_l = tk.Entry(f)
        self.e_l.grid(row=0, column=1, sticky="ew", pady=5)
        tk.Label(f, text="Пароль:").grid(row=1, column=0, sticky="e", padx=5, pady=5)
        self.e_p = tk.Entry(f, show="*")
        self.e_p.grid(row=1, column=1, sticky="ew", pady=5)
        f.columnconfigure(1, weight=1)
        tk.Button(self, text="Войти", command=self._go).pack(pady=15)
        self.bind("<Return>", lambda e: self._go())
        self.e_l.focus_set()

    def _go(self):
        l, p = self.e_l.get().strip(), self.e_p.get().strip()
        if not l or not p:
            return messagebox.showwarning("Внимание", "Заполните все обязательные поля")
        Captcha(self, lambda ok: self._after(l, p, ok))

    def _after(self, l, p, ok):
        if not ok:
            return self._bad(l)
        r = UserManager.auth(l, p, ok)
        if r == "blocked":
            return messagebox.showerror("Блокировка", ERR_BLK)
        if r == "fail":
            return self._bad(l)
        messagebox.showinfo("Успех", MSG_OK)
        self.destroy()
        Admin() if r == "admin" else UserWin()

    def _bad(self, l):
        r = UserManager.auth(l, "x", False)
        messagebox.showerror("Ошибка", ERR_PWD if r != "blocked" else ERR_BLK)


class Admin(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Панель администратора - {COMPANY}")
        self.geometry("600x400")
        self.minsize(500, 300)
        self.tree = ttk.Treeview(self, columns=("l", "r", "s"), show="headings")
        self.tree.heading("l", text="Логин")
        self.tree.heading("r", text="Роль")
        self.tree.heading("s", text="Статус")
        self.tree.pack(fill="both", expand=True, padx=10, pady=5)
        bf = tk.Frame(self)
        bf.pack(fill="x", padx=10, pady=5)
        tk.Button(bf, text="Добавить", command=self._add).pack(side="left", padx=5)
        tk.Button(bf, text="Изменить роль", command=self._role).pack(side="left", padx=5)
        tk.Button(bf, text="Разблокировать", command=self._unblock).pack(side="left", padx=5)
        tk.Button(bf, text="Выход", command=self.destroy).pack(side="right", padx=5)
        self._reload()

    def _reload(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        for l, r, b in UserManager.list_users():
            self.tree.insert("", "end", values=(l, r, "Заблокирован" if b else "Активен"))

    def _add(self):
        l = simpledialog.askstring("Новый пользователь", "Введите логин:")
        if l and UserManager.add_user(l.strip()):
            messagebox.showinfo("Успех", f"Пользователь добавлен. Пароль: {DEF_PWD}")
            self._reload()
        elif l:
            messagebox.showerror("Ошибка", "Пользователь с таким логином уже существует")

    def _role(self):
        s = self.tree.selection()
        if not s:
            return messagebox.showwarning("Внимание", "Выберите пользователя")
        l = self.tree.item(s[0])["values"][0]
        r = simpledialog.askstring("Роль", "Введите роль (admin/user):", initialvalue="user")
        if r in ("admin", "user"):
            UserManager.set_role(l, r)
            self._reload()

    def _unblock(self):
        s = self.tree.selection()
        if not s:
            return messagebox.showwarning("Внимание", "Выберите пользователя")
        UserManager.unblock(self.tree.item(s[0])["values"][0])
        messagebox.showinfo("Успех", "Пользователь разблокирован")
        self._reload()


class UserWin(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Рабочий стол - {COMPANY}")
        self.geometry("400x200")
        tk.Label(self, text="Добро пожаловать в систему.").pack(pady=50)
        tk.Button(self, text="Выход", command=self.destroy).pack(pady=10)
