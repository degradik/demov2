import psycopg2
from passlib.hash import bcrypt
from tkinter import messagebox

PG = {
    "host": "localhost",
    "dbname": "V2",
    "port": "5433",
    "user": "postgres",
    "password": "87654321",
}

COMPANY = 'ООО "Хлебус"'
ERR_PWD = "Вы ввели неверный логин или пароль. Пожалуйста проверьте ещё раз введенные данные"
ERR_BLK = "Вы заблокированы. Обратитесь к администратору"
MSG_OK = "Вы успешно авторизовались"
DEF_PWD = "12345"


class UserManager:
    @staticmethod
    def _conn():
        c = psycopg2.connect(**PG)
        c.set_client_encoding("UTF8")
        return c

    @staticmethod
    def init_db():
        with UserManager._conn() as conn, conn.cursor() as cur:
            cur.execute("""CREATE TABLE IF NOT EXISTS users (
                login VARCHAR(50) PRIMARY KEY, password_hash VARCHAR(100) NOT NULL,
                role VARCHAR(20) DEFAULT 'user', is_blocked BOOLEAN DEFAULT FALSE,
                failed_attempts INTEGER DEFAULT 0)""")
            cur.execute("SELECT 1 FROM users WHERE login='admin'")
            if not cur.fetchone():
                cur.execute(
                    "INSERT INTO users VALUES (%s,%s,'admin',FALSE,0)",
                    ("admin", bcrypt.using(rounds=4).hash("admin")),
                )
            conn.commit()

    @staticmethod
    def auth(login, pwd, captcha_ok):
        try:
            with UserManager._conn() as conn, conn.cursor() as cur:
                cur.execute("SELECT password_hash,role,is_blocked FROM users WHERE login=%s", (login,))
                r = cur.fetchone()
                if not r:
                    return "fail"
                ph, role, blk = r
                if blk:
                    return "blocked"
                if bcrypt.verify(pwd, ph) and captcha_ok:
                    cur.execute("UPDATE users SET failed_attempts=0 WHERE login=%s", (login,))
                    conn.commit()
                    return role
                cur.execute(
                    "UPDATE users SET failed_attempts=failed_attempts+1, "
                    "is_blocked=(failed_attempts+1>=3) WHERE login=%s RETURNING is_blocked",
                    (login,),
                )
                conn.commit()
                return "blocked" if cur.fetchone()[0] else "fail"
        except Exception as e:
            messagebox.showerror("Ошибка БД", str(e))
            return "fail"

    @staticmethod
    def list_users():
        with UserManager._conn() as conn, conn.cursor() as cur:
            cur.execute("SELECT login,role,is_blocked FROM users ORDER BY login")
            return cur.fetchall()

    @staticmethod
    def add_user(login):
        try:
            with UserManager._conn() as conn, conn.cursor() as cur:
                cur.execute("SELECT 1 FROM users WHERE login=%s", (login,))
                if cur.fetchone():
                    return False
                cur.execute(
                    "INSERT INTO users VALUES (%s,%s,'user',FALSE,0)",
                    (login, bcrypt.using(rounds=4).hash(DEF_PWD)),
                )
                conn.commit()
            return True
        except Exception as e:
            messagebox.showerror("Ошибка БД", str(e))
            return False

    @staticmethod
    def set_role(login, role):
        with UserManager._conn() as conn, conn.cursor() as cur:
            cur.execute("UPDATE users SET role=%s WHERE login=%s", (role, login))
            conn.commit()

    @staticmethod
    def unblock(login):
        with UserManager._conn() as conn, conn.cursor() as cur:
            cur.execute("UPDATE users SET is_blocked=FALSE, failed_attempts=0 WHERE login=%s", (login,))
            conn.commit()
