import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from tkinter import messagebox

from entities.user_manager import UserManager
from forms.forms import Login


def main():
    try:
        UserManager.init_db()
    except Exception as e:
        messagebox.showerror("Ошибка", f"Нет связи с PostgreSQL:\n{e}")
        sys.exit(1)
    Login().mainloop()


if __name__ == "__main__":
    main()
