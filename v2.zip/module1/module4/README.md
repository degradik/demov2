# Модуль 4

```
module4/
├── main.py
├── requirements.txt
├── entities/
│   ├── __init__.py
│   └── user_manager.py
├── forms/
│   ├── __init__.py
│   └── forms.py
└── images/
    ├── 1.png … 4.png
```

## Запуск (РЕД ОС, без sudo)

```bash
pip install --user -r requirements.txt
# PostgreSQL и БД V2 должны быть уже запущены
python3 main.py
```

Настройки БД: `entities/user_manager.py` (PG).  
Логин: **admin** / **admin**

Подробнее: [../README.md](../README.md)
