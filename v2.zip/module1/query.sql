-- PostgreSQL, module 3
-- Full buyer order cost = sum(order qty * material cost per product unit from BOM)
-- Material cost per unit = sum(spec qty * material price) for each product
-- Run: psql -U postgres -d V2 -f query.sql

SELECT
    o.id AS order_id,
    o.order_date,
    c.name AS customer_name,
    SUM(
        oi.quantity * COALESCE(prod_cost.material_cost_per_unit, 0)
    ) AS total_material_cost
FROM orders o
INNER JOIN customers c ON o.customer_id = c.id
INNER JOIN order_items oi ON o.id = oi.order_id
LEFT JOIN (
    SELECT
        sp.product_id,
        SUM(sp.quantity * m.price) AS material_cost_per_unit
    FROM specifications sp
    INNER JOIN materials m ON sp.material_id = m.id
    GROUP BY sp.product_id
) prod_cost ON oi.product_id = prod_cost.product_id
GROUP BY o.id, o.order_date, c.name
ORDER BY o.id;

-- order_id=1 (bun with BOM): total_material_cost = 52.88
-- order_id=3 (bread only, no BOM in appendix): total_material_cost = 0
